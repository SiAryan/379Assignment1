Aryan Singh <br />
CMPUT 379 Assignment 1 <br />
University of Alberta

Resources used: <br />
<br />
1. http://www.cplusplus.com/reference/cstring/strtok/ <br />
2. http://www.cplusplus.com/reference/cstring/strcmp/ <br />
3. https://youtu.be/9RJTQmK0YPI <br />
4. http://www.cplusplus.com/reference/regex/ <br />
5. https://www.w3schools.com/cpp/cpp_do_while_loop.asp <br />
6. https://www.w3schools.com/cpp/cpp_conditions_shorthand.asp <br />
